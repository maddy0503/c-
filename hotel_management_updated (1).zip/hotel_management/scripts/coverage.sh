#!/usr/bin/env bash
# Runs the tests of a --coverage build and reports LINE, FUNCTION and BRANCH
# coverage for src/ and include/.
#
#   * Console table + build/cov/report/coverage.txt always (needs only gcc/gcov + python3).
#   * Extra HTML report (with per-line, per-function and per-branch detail) when
#     gcovr or lcov is installed.
#
# Usage: scripts/coverage.sh <build-dir>   (default: build/cov)
# Env:   COVERAGE_MIN=80         fail if line coverage is below 80%
#        COVERAGE_FUNC_MIN=80    fail if function coverage is below 80%
#        COVERAGE_BRANCH_MIN=60  fail if branch coverage is below 60%
set -euo pipefail

BUILD="${1:-build/cov}"
REPORT="$BUILD/report"

find "$BUILD" -name '*.gcda' -delete      # forget earlier runs
"$BUILD/hotel_tests"
mkdir -p "$REPORT"

# Optional HTML report (never decides pass/fail).
if command -v gcovr >/dev/null; then
    gcovr --root . --filter 'src/' --filter 'include/' --exclude-throw-branches \
          --html-details "$REPORT/index.html" "$BUILD" >/dev/null \
        && echo "HTML report: $REPORT/index.html"
elif command -v lcov >/dev/null && command -v genhtml >/dev/null; then
    lcov --capture --directory "$BUILD" --output-file "$REPORT/all.info" --quiet \
         --rc branch_coverage=1 --ignore-errors mismatch,inconsistent
    lcov --extract "$REPORT/all.info" "$PWD/src/*" "$PWD/include/*" --output-file "$REPORT/lcov.info" \
         --quiet --rc branch_coverage=1
    genhtml "$REPORT/lcov.info" --output-directory "$REPORT" --quiet --branch-coverage \
        && echo "HTML report: $REPORT/index.html"
fi

# Console summary + thresholds.
python3 "$(dirname "$0")/coverage_report.py" "$BUILD"
echo "Text report: $REPORT/coverage.txt"
