#!/usr/bin/env bash
# Runs the unit tests and a scripted app session under valgrind and prints, for each run:
#   * total heap allocation  (allocs / frees / total bytes allocated)
#   * peak-free summary      (bytes still in use at exit = leaks)
#   * leak summary and error count
# Full valgrind logs are kept in <build-dir>/valgrind/.
# Usage: scripts/run_valgrind.sh <build-dir>   (default: build/debug)
set -euo pipefail

BUILD="$(cd "${1:-build/debug}" && pwd)"
HERE="$(cd "$(dirname "$0")" && pwd)"
LOGDIR="$BUILD/valgrind"
if ! command -v valgrind >/dev/null; then
    echo "valgrind not found. Install it (e.g. 'sudo apt install valgrind') or use 'make sanitize'." >&2
    exit 1
fi
mkdir -p "$LOGDIR"

# No --quiet: the HEAP SUMMARY / LEAK SUMMARY lines are what we want to report.
vg() {   # vg <logfile>  -> valgrind command prefix
    echo "valgrind --leak-check=full --show-leak-kinds=definite,possible --errors-for-leak-kinds=definite,possible \
--track-origins=yes --error-exitcode=1 --log-file=$1"
}

strip() { sed -E 's/^==[0-9]+== ?//'; }

summary() {   # summary <title> <logfile> <exit-status>
    local title="$1" log="$2" status="$3"
    echo
    echo "---- $title ----"
    grep -E 'total heap usage' "$log" | strip | sed -E 's/^ +//' | sed 's/^/  /'
    grep -E 'in use at exit' "$log" | strip | sed -E 's/^ +/  /'
    if grep -q 'All heap blocks were freed' "$log"; then
        echo "  All heap blocks were freed -- no leaks"
    else
        sed -n '/LEAK SUMMARY/,/^==[0-9]*== *$/p' "$log" | strip | sed -E 's/^ +/  /'
    fi
    grep -E 'ERROR SUMMARY' "$log" | strip | sed -E 's/^ +/  /'
    echo "  full log: $log"
    if [ "$status" -ne 0 ]; then
        echo "  >>> valgrind reported problems:" >&2
        grep -vE '^==[0-9]+== *$' "$log" | strip | head -60 >&2
    fi
}

rc=0

TEST_LOG="$LOGDIR/tests.log"
echo "== unit tests under valgrind =="
set +e
$(vg "$TEST_LOG") "$BUILD/hotel_tests" > "$LOGDIR/tests.out" 2>&1
t=$?
set -e
tail -n 4 "$LOGDIR/tests.out"
summary "unit tests (gtest)" "$TEST_LOG" "$t"
[ "$t" -ne 0 ] && rc=1

APP_LOG="$LOGDIR/app.log"
echo
echo "== app session under valgrind =="
set +e
RUNNER="$(vg "$APP_LOG")" "$HERE/run_app_session.sh" "$BUILD/hotel_app"
a=$?
set -e
summary "hotel_app scripted session" "$APP_LOG" "$a"
[ "$a" -ne 0 ] && rc=1

echo
if [ "$rc" -eq 0 ]; then
    echo "valgrind: no memory errors or leaks"
else
    echo "valgrind: FAILED (see logs in $LOGDIR)" >&2
fi
exit "$rc"
