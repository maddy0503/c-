#include "hotel/room.hpp"

namespace hotel {

std::unique_ptr<Room> makeRoom(RoomType type, int number) {
    switch (type) {
        case RoomType::Single: return std::make_unique<SingleRoom>(number);
        case RoomType::Double: return std::make_unique<DoubleRoom>(number);
        case RoomType::Deluxe: return std::make_unique<DeluxeRoom>(number);
        case RoomType::Suite:  return std::make_unique<SuiteRoom>(number);
    }
    return nullptr;
}

}  // namespace hotel
