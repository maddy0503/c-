#include <gtest/gtest.h>

#include "hotel/date_utils.hpp"

using namespace hotel;

TEST(DateUtils, EpochIsDayZero) {
    EXPECT_EQ(daysFromCivil(1970, 1, 1), 0);
    EXPECT_EQ(dayToString(0), "1970-01-01");
}

TEST(DateUtils, KnownDates) {
    EXPECT_EQ(daysFromCivil(2000, 1, 1), 10957);
    EXPECT_EQ(dayToString(10957), "2000-01-01");
    EXPECT_EQ(dayToString(-1), "1969-12-31");
}

TEST(DateUtils, ConsecutiveDaysAcrossMonthAndYearBoundaries) {
    EXPECT_EQ(daysFromCivil(2024, 3, 1) - daysFromCivil(2024, 2, 28), 2);  // leap year
    EXPECT_EQ(daysFromCivil(2023, 3, 1) - daysFromCivil(2023, 2, 28), 1);
    EXPECT_EQ(daysFromCivil(2025, 1, 1) - daysFromCivil(2024, 12, 31), 1);
}

TEST(DateUtils, RoundTripsOverManyYears) {
    for (int day = daysFromCivil(1990, 1, 1); day <= daysFromCivil(2040, 12, 31); day += 7) {
        auto parsed = parseDate(dayToString(day));
        ASSERT_TRUE(parsed.has_value()) << dayToString(day);
        EXPECT_EQ(*parsed, day);
    }
}

TEST(DateUtils, NegativeYearsStillFormat) {
    const int day = daysFromCivil(-5, 6, 15);
    EXPECT_EQ(dayToString(day), "-005-06-15");
}

TEST(DateUtils, ParseAcceptsValidDates) {
    EXPECT_EQ(parseDate("1970-01-01"), 0);
    EXPECT_TRUE(parseDate("2024-02-29").has_value());  // leap day
}

TEST(DateUtils, ParseRejectsInvalidDates) {
    EXPECT_FALSE(parseDate("").has_value());
    EXPECT_FALSE(parseDate("2023-02-29").has_value());  // not a leap year
    EXPECT_FALSE(parseDate("2030-02-31").has_value());
    EXPECT_FALSE(parseDate("2030-13-01").has_value());
    EXPECT_FALSE(parseDate("2030-00-10").has_value());
    EXPECT_FALSE(parseDate("2030-1-1").has_value());     // wrong length
    EXPECT_FALSE(parseDate("2030/01/01").has_value());   // wrong separator
    EXPECT_FALSE(parseDate("abcd-ef-gh").has_value());
    EXPECT_FALSE(parseDate("2030-01-011").has_value());
}

TEST(DateUtils, TodayIsPlausibleAndStable) {
    const int t = todayDay();
    EXPECT_GT(t, daysFromCivil(2024, 1, 1));
    EXPECT_LT(t, daysFromCivil(2200, 1, 1));
    EXPECT_NEAR(todayDay(), t, 1);  // allow for a midnight rollover
}
