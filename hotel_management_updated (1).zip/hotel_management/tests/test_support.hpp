#pragma once
#include <unistd.h>

#include <filesystem>
#include <fstream>
#include <string>

#include "hotel/date_utils.hpp"

namespace test {

// A throw-away data directory, removed when the object goes out of scope.
class TempDir {
public:
    TempDir() {
        static int counter = 0;
        path_ = std::filesystem::temp_directory_path() /
                ("hotel_test_" + std::to_string(::getpid()) + "_" + std::to_string(counter++));
        std::filesystem::remove_all(path_);
    }
    ~TempDir() {
        std::error_code ec;
        std::filesystem::remove_all(path_, ec);
    }
    TempDir(const TempDir&) = delete;
    TempDir& operator=(const TempDir&) = delete;

    std::string str() const { return path_.string(); }
    std::filesystem::path file(const std::string& name) const { return path_ / name; }

    // Writes (and creates the directory if needed) a data file with the given content.
    void write(const std::string& name, const std::string& content) const {
        std::filesystem::create_directories(path_);
        std::ofstream(path_ / name) << content;
    }
    std::string read(const std::string& name) const {
        std::ifstream in(path_ / name);
        return {std::istreambuf_iterator<char>(in), std::istreambuf_iterator<char>()};
    }

private:
    std::filesystem::path path_;
};

inline int tomorrow() { return hotel::todayDay() + 1; }

}  // namespace test
